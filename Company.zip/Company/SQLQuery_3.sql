-- Create Department table
CREATE TABLE Department(
    DName VARCHAR(50) UNIQUE NOT NULL,
    DNumber INT PRIMARY KEY
);
GO



