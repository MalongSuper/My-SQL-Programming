CREATE DATABASE AkademiHighSchool;
GO

USE AkademiHighSchool;
GO

-- Drop and Backup Database
-- DROP DATABASE AkademiHighSchool
-- GO

-- BACKUP DATABASE AkademiHighSchool
-- TO DISK = '/Users/yourusername/backups/testDB.bak';
-- GO
