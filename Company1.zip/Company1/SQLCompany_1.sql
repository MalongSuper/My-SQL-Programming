CREATE DATABASE Company ON  PRIMARY 
	( NAME = 'Company', 
	FILENAME = '/Users/macbook/Downloads/Company.mdf' , 
	SIZE = 3072KB, 
 	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 1024KB )
 LOG ON 
	( NAME = 'Company_log', 
	FILENAME = '/Users/macbook/DownloadsCompany_log.ldf' , 
	SIZE = 1024KB , 
	MAXSIZE = 2048KB , 
	FILEGROWTH = 10%);
GO