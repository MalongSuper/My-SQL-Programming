-- This mergres Works_On and Employee
SELECT * FROM Works_On JOIN Employee e ON ESSN = e.SSN
