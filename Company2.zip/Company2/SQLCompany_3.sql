-- Display all tables
SELECT * FROM Department;
SELECT * FROM Employee;
SELECT * FROM Dept_Location;
SELECT * FROM Project;
SELECT * FROM Works_On;
SELECT * FROM Dependent;