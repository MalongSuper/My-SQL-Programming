SELECT AVG(Salary) AS sal_avg_fem FROM Employee WHERE Sex = 'F';
GO
