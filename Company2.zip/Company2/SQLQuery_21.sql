SELECT MAX(Salary) AS sal_max , MIN(Salary) AS sal_min, 
AVG(Salary) AS sal_avg, COUNT(SSN) AS emp_qty FROM Employee;
GO