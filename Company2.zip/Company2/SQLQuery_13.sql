SELECT * FROM Employee WHERE (Salary >= 30000 AND Salary <= 50000) ORDER BY Salary DESC;
GO



