SELECT * INTO employee_Backup FROM Employee;
SELECT * FROM Employee;
SELECT * FROM employee_Backup;
GO