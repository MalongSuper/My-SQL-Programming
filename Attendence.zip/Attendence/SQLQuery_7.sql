INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (1, 'AI1233203_01', '2024-05-16', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (2, 'AI1233203_01', '2024-05-18', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (3, 'AI1233203_01', '2024-05-20', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (4, 'AI1233203_01', '2024-05-22', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (5, 'AI1233203_01', '2024-05-24', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (6, 'AI1233203_01', '2024-05-26', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (7, 'AI1233203_01', '2024-05-28', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (8, 'AI1233203_01', '2024-05-30', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (9, 'AI1233203_01', '2024-06-01', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (10, 'AI1233203_01', '2024-06-03', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (11, 'AI1233203_01', '2024-06-05', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (12, 'AI1233203_01', '2024-06-07', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (13, 'AI1233203_01', '2024-06-09', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (14, 'AI1233203_01', '2024-06-11', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (15, 'AI1233203_01', '2024-06-13', '10:00', 3);


INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (1, 'AI1233203_02', '2024-05-16', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (2, 'AI1233203_02', '2024-05-18', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (3, 'AI1233203_02', '2024-05-20', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (4, 'AI1233203_02', '2024-05-22', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (5, 'AI1233203_02', '2024-05-24', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (6, 'AI1233203_02', '2024-05-26', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (7, 'AI1233203_02', '2024-05-28', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (8, 'AI1233203_02', '2024-05-30', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (9, 'AI1233203_02', '2024-06-01', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (10, 'AI1233203_02', '2024-06-03', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (11, 'AI1233203_02', '2024-06-05', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (12, 'AI1233203_02', '2024-06-07', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (13, 'AI1233203_02', '2024-06-09', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (14, 'AI1233203_02', '2024-06-11', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (15, 'AI1233203_02', '2024-06-13', '10:00', 3);


INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (1, 'AI1233203_03', '2024-05-16', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (2, 'AI1233203_03', '2024-05-18', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (3, 'AI1233203_03', '2024-05-20', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (4, 'AI1233203_03', '2024-05-22', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (5, 'AI1233203_03', '2024-05-24', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (6, 'AI1233203_03', '2024-05-26', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (7, 'AI1233203_03', '2024-05-28', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (8, 'AI1233203_03', '2024-05-30', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (9, 'AI1233203_03', '2024-06-01', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (10, 'AI1233203_03', '2024-06-03', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (11, 'AI1233203_03', '2024-06-05', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (12, 'AI1233203_03', '2024-06-07', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (13, 'AI1233203_03', '2024-06-09', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (14, 'AI1233203_03', '2024-06-11', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (15, 'AI1233203_03', '2024-06-13', '10:00', 3);


INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (1, 'AI1233203_04', '2024-05-16', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (2, 'AI1233203_04', '2024-05-18', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (3, 'AI1233203_04', '2024-05-20', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (4, 'AI1233203_04', '2024-05-22', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (5, 'AI1233203_04', '2024-05-24', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (6, 'AI1233203_04', '2024-05-26', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (7, 'AI1233203_04', '2024-05-28', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (8, 'AI1233203_04', '2024-05-30', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (9, 'AI1233203_04', '2024-06-01', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (10, 'AI1233203_04', '2024-06-03', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (11, 'AI1233203_04', '2024-06-05', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (12, 'AI1233203_04', '2024-06-07', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (13, 'AI1233203_04', '2024-06-09', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (14, 'AI1233203_04', '2024-06-11', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (15, 'AI1233203_04', '2024-06-13', '10:00', 3);


INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (1, 'AI1233203_05', '2024-05-16', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (2, 'AI1233203_05', '2024-05-18', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (3, 'AI1233203_05', '2024-05-20', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (4, 'AI1233203_05', '2024-05-22', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (5, 'AI1233203_05', '2024-05-24', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (6, 'AI1233203_05', '2024-05-26', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (7, 'AI1233203_05', '2024-05-28', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (8, 'AI1233203_05', '2024-05-30', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (9, 'AI1233203_05', '2024-06-01', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (10, 'AI1233203_05', '2024-06-03', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (11, 'AI1233203_05', '2024-06-05', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (12, 'AI1233203_05', '2024-06-07', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (13, 'AI1233203_05', '2024-06-09', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (14, 'AI1233203_05', '2024-06-11', '10:00', 3);
INSERT INTO ClassDay(ClassNumber, ClassId, ClassDate, ClassTime, NumberofPeriods) VALUES (15, 'AI1233203_05', '2024-06-13', '10:00', 3);
