-- This create two files
CREATE DATABASE Attendence
GO